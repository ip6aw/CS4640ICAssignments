# TutSearch

TutSearch is a platform that emables students to lookup college tutors and schedule classes with them. This plaform is powered on HTML, Javascript, PHP, JSP, MySQL.

For class CS 4640 at the University of Virginia, made by:
  - Shabad Sobti
  - Ibad Pathan